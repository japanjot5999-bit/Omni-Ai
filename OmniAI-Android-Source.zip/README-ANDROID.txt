OMNIAI ANDROID WRAPPER — SOURCE PROJECT

This is a real Android WebView wrapper project for:
https://omniai-4fxu6w.v2.appdeploy.ai/

It is NOT a compiled APK. The included GitHub Actions workflow builds a debug APK
in GitHub's cloud runner, so no PC or Android Studio is required.

PHONE-ONLY BUILD STEPS
1. Download and extract this ZIP on your Android phone.
2. In your browser, create/open a GitHub repository.
3. Upload the extracted project files and folders to the repository (keep folder
   structure, including .github/workflows/build-apk.yml).
4. Open the repository's Actions tab.
5. Choose "Build OmniAI APK" and tap "Run workflow".
6. When it finishes, open the run and download the "OmniAI-debug-apk" artifact.
7. Extract the artifact ZIP and install app-debug.apk.

IMPORTANT
- This wrapper loads the existing online OmniAI app; internet is required.
- It does not make the AI work offline.
- Google sign-in is sent to the system browser because Google may block login
  inside embedded WebViews. Whether the login session returns to the app must
  be tested on the target phone.
- This is a debug APK for personal testing, not a Play Store release.
- Do not share signing keys or API keys in the repository.
